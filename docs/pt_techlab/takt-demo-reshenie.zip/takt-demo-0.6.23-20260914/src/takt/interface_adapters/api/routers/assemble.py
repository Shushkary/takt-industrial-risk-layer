from __future__ import annotations

from fastapi import HTTPException
from pydantic import BaseModel, Field

from takt.application.use_cases.assemble_incident import (
    AssembleIncidentUseCase,
    IncidentSeed,
)
from takt.application.use_cases.auto_assemble_incidents import AutoAssembleIncidentsUseCase
from takt.interface_adapters.api.dependencies import ApiContext
from takt.interface_adapters.api.schemas.errors import CONFLICT_OPENAPI


class AssembleIncidentRequest(BaseModel):
    """Сборка инцидента пивотом по отличительным сущностям."""

    case_id: str = Field(min_length=1, max_length=64)
    seeds: list[str] = Field(min_length=1, max_length=32)
    title: str = ""
    expand_hosts: list[str] = Field(default_factory=list, max_length=32)
    expand_padding_sec: int = Field(default=0, ge=0, le=86400)
    actor: str = ""


class AssembleIncidentResponse(BaseModel):
    case_id: str
    core_events: int
    expanded_events: int
    total_events: int
    source_case_ids: list[str]


class AutoAssembleRequest(BaseModel):
    """Автоматическая сборка ядра инцидентов по делам со срабатыванием инварианта."""

    distinctive_max_events: int = Field(
        default=12,
        ge=1,
        le=1000,
        description=(
            "Сущность считается отличительной, если встречается в принятом потоке не чаще"
            " этого числа раз. Выше порог — полнее цепочка и больше фона вместе с ней."
        ),
    )
    actor: str = ""


class AutoAssembledIncidentOut(BaseModel):
    case_id: str
    seeds: list[str]
    event_count: int
    source_case_ids: list[str]


class AutoAssembleResponse(BaseModel):
    incidents: list[AutoAssembledIncidentOut]
    considered_cases: list[str]
    skipped_cases: list[str]
    # Редакции инцидента, собранные по неполному потоку и этим прогоном не воспроизведённые:
    # закрыты как MERGED. Пустой список — прогон ничего не снимал.
    retired_case_ids: list[str] = []


def register_assemble_routes(ctx: ApiContext) -> None:
    app = ctx.app

    @app.post(
        "/cases/assemble/pivot",
        response_model=AssembleIncidentResponse,
        tags=["Cases"],
        responses=CONFLICT_OPENAPI,
    )
    def assemble_by_pivot_endpoint(request: AssembleIncidentRequest) -> AssembleIncidentResponse:
        """Собирает кейс из уже принятых событий. Группировка, не действие и не вердикт."""
        store = getattr(app.state, "recent_event_store", None)
        if store is None:
            raise HTTPException(
                status_code=409,
                detail="сборка инцидента требует постоянного хранилища событий (TAKT_STORAGE=sqlite)",
            )
        try:
            seeds = [IncidentSeed.parse(item) for item in request.seeds]
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        use_case = AssembleIncidentUseCase(
            events=store,
            repo=ctx.repo,
            weights=getattr(app.state, "risk_weights", {}),
        )
        try:
            assembled = use_case.execute(
                case_id=request.case_id,
                seeds=seeds,
                title=request.title,
                expand_hosts=tuple(request.expand_hosts),
                expand_padding_sec=request.expand_padding_sec,
                actor=request.actor,
            )
        except LookupError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        return AssembleIncidentResponse(
            case_id=assembled.case.case_id,
            core_events=len(assembled.core_event_ids),
            expanded_events=len(assembled.expanded_event_ids),
            total_events=assembled.total_events,
            source_case_ids=list(assembled.source_case_ids),
        )

    @app.post(
        "/cases/assemble/auto",
        response_model=AutoAssembleResponse,
        tags=["Cases"],
        responses=CONFLICT_OPENAPI,
    )
    def assemble_auto_endpoint(request: AutoAssembleRequest) -> AutoAssembleResponse:
        """Повторяет сборку ядра инцидентов по требованию — с другим порогом отличительности.

        Тот же шаг конвейер выполняет сам при приёме событий (`incident_assembly.on_ingest`),
        поэтому обычно вызывать этот метод не нужно: он существует для повторного разбора с
        другим порогом и для установок, где сборка на приёме выключена.

        Отбор — по отличительным сущностям дел, где сработал инвариант. Расширение до уровня
        узла сюда не входит: оно добирает штатную активность и остаётся решением аналитика.
        """
        store = getattr(app.state, "recent_event_store", None)
        if store is None:
            raise HTTPException(
                status_code=409,
                detail="сборка инцидента требует постоянного хранилища событий (TAKT_STORAGE=sqlite)",
            )
        use_case = AutoAssembleIncidentsUseCase(
            assemble=AssembleIncidentUseCase(
                events=store, repo=ctx.repo, weights=getattr(app.state, "risk_weights", {})
            ),
            repo=ctx.repo,
            events=store,
            distinctive_max_events=request.distinctive_max_events,
        )
        report = use_case.execute(actor=request.actor or "auto-assembly")
        return AutoAssembleResponse(
            incidents=[
                AutoAssembledIncidentOut(
                    case_id=item.case_id,
                    seeds=list(item.seeds),
                    event_count=item.event_count,
                    source_case_ids=list(item.source_case_ids),
                )
                for item in report.incidents
            ],
            considered_cases=list(report.considered_cases),
            skipped_cases=list(report.skipped_cases),
            retired_case_ids=list(report.retired_case_ids),
        )
