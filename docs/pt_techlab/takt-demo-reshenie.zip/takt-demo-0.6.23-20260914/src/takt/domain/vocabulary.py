"""Русские названия обозначений продукта — единый источник правды.

Интерфейс аналитика показывает не коды, а слова: не ``LOW``, а «низкий», не ``auth_logs``, а
«журналы аутентификации». Раньше такие подписи жили бы в двух местах — в API и в АРМ — и
разошлись бы при первом же добавлении статуса или источника. Здесь один словарь, который
отдаётся наружу через ``GET /catalog/vocabulary``.

Что переводится и что нет — граница проходит по происхождению значения:

- **Наши обозначения** переводятся: класс риска, статус дела, триадный вердикт, класс источника,
  тип сущности и артефакта. Их придумал продукт, и показывать их кодом незачем.
- **Значения из данных источника** не переводятся: операция (``WRITE_REGISTER``), протокол
  (``MODBUS``), идентификаторы узлов и учётных записей. Это материал доказательства; перевод
  исказил бы то, что зафиксировано в журнале, и предъявить такой перевод экспертизе нельзя.

Полнота словаря проверяется тестом: новый член перечисления без русского названия роняет
прогон, а не показывается пользователю кодом.
"""

from __future__ import annotations

from takt.domain.entities.case import CaseStatus
from takt.domain.entities.event import ArtifactType, EventSource

RISK_CLASS_RU: dict[str, str] = {
    "LOW": "низкий",
    "MEDIUM": "средний",
    "HIGH": "высокий",
    "CRITICAL": "критический",
}

CASE_STATUS_RU: dict[str, str] = {
    CaseStatus.NEW.value: "новое",
    CaseStatus.TRIAGE.value: "в разборе",
    CaseStatus.CONFIRMED.value: "подтверждено",
    CaseStatus.FALSE_POSITIVE.value: "ложное срабатывание",
    CaseStatus.EXPECTED_BEHAVIOR.value: "штатное действие",
    CaseStatus.MERGED.value: "объединено",
}

CASE_COVERAGE_RU: dict[str, str] = {
    "full": "разобрано целиком",
    "partial": "разобрано частично",
}
"""Покрытие состава исходного дела собранным инцидентом.

Дело конвейера остаётся в очереди и после того, как его события вошли в собранный инцидент и
были там разобраны: обратной ссылки у исходного дела нет, и в очереди оно выглядит нетронутым.
«Целиком» — в собранный инцидент вошли все события дела, «частично» — часть: пересборка меняет
состав в обе стороны, и приписать полное покрытие там, где его нет, значило бы спрятать от
аналитика неразобранный остаток."""

PROCESS_IDENTITY_RU: dict[str, str] = {
    "guid": "идентификатор запуска",
    "host_pid": "узел и PID",
    "undetermined": "узел неизвестен",
}
"""Чем опознан процесс в карточке сущности.

PID уникален в пределах узла и переиспользуется после завершения процесса, поэтому ключом
сам по себе не является. Читающий должен видеть границу: «идентификатор запуска» сходится
между источниками, «узел и PID» разводит узлы, но не различает повторные запуски на одном
узле, «узел неизвестен» не сводится ни с чем."""

ANALYTIC_CONFIDENCE_RU: dict[str, str] = {
    "high": "высокая",
    "moderate": "средняя",
    "low": "низкая",
}
"""Уверенность аналитика в собственной оценке (итоговое описание расследования).

Это не вероятность и не оценка продукта: продукт своего вердикта уверенностью не снабжает и
за человека её не выбирает. Поле существует потому, что оценка без выраженной уверенности
читается как установленный факт — то же различение, что между «точкой входа» и гипотезой в
реконструкции цепочки."""

VERDICT_RU: dict[str, str] = {
    "LEG": "легитимное",
    "ILLEG": "нелегитимное",
    "UNDET": "неопределённое",
}

PERMIT_VERDICT_RU: dict[str, str] = {
    "legitimate": "легитимное",
    "illegitimate": "нелегитимное",
    "undetermined": "неопределённое",
}
"""Вердикт сверки организационного документа с делом (`manual_permits[].verdict`).

Та же триада, что и `VERDICT_RU`, но другими обозначениями: сценарий наряда пишет их
полными словами, и значения уже лежат в сохранённых делах и в выгруженных доказательных
пакетах. Свести обозначения к одному набору — отдельное решение о совместимости данных,
а не правка словаря; пока таблиц две, интерфейс берёт названия отсюда, а не изобретает свои."""

EVENT_SOURCE_RU: dict[str, str] = {
    EventSource.EDR.value: "защита рабочих станций",
    EventSource.SIEM.value: "система сбора событий",
    EventSource.NDR.value: "анализ сетевого трафика",
    EventSource.OT.value: "промышленная телеметрия",
    EventSource.AUTH_LOGS.value: "журналы аутентификации",
    EventSource.NETWORK.value: "сетевые события",
    EventSource.PLC_POLLING.value: "опрос контроллеров",
    EventSource.SERVICE_DESK.value: "служба заявок",
    EventSource.UNKNOWN.value: "источник не определён",
}

ENTITY_TYPE_RU: dict[str, str] = {
    "host": "узел",
    "user": "учётная запись",
    "process": "процесс",
    "address": "адрес",
    "destination": "адрес назначения",
}

ARTIFACT_TYPE_RU: dict[str, str] = {
    ArtifactType.HOST.value: "узел",
    ArtifactType.FILE.value: "файл",
    ArtifactType.HASH.value: "контрольная сумма",
    ArtifactType.PROCESS.value: "процесс",
    ArtifactType.ACCOUNT.value: "учётная запись",
    ArtifactType.ADDRESS.value: "адрес",
    ArtifactType.URL.value: "ссылка",
    ArtifactType.DOMAIN.value: "домен",
    ArtifactType.SPN.value: "служба Kerberos",
    ArtifactType.REPO.value: "репозиторий кода",
}

WORK_PHASE_RU: dict[str, str] = {
    "WORK_SHIFT": "рабочая смена",
    "NIGHT": "ночь",
    "WEEKEND": "выходной",
}

CONFIDENCE_GRADE_RU: tuple[str, ...] = ("высокая", "средняя", "низкая")
"""Оценки обоснованности вывода. Уже по-русски — перечислены для полноты словаря."""

CORRELATION_RULE_RU: dict[str, str] = {
    "pivot": "ядро",
    "host-expansion": "расширение",
    "manual_attach": "прицеплено аналитиком",
    "manual_detach": "отцеплено аналитиком",
    "manual_merge": "объединено аналитиком",
    "manual_split": "разделено аналитиком",
}
"""Основание попадания события в кейс (`correlation_evidence.rule`)."""

CHAIN_STEP_KIND_RU: dict[str, str] = {
    "process_spawn": "запуск процесса",
    "process_observed": "процесс наблюдался",
    "network_move": "сетевое перемещение",
}
"""Вид перехода в реконструкции цепочки (`attack_chain.steps[].kind`)."""

GRAPH_EDGE_KIND_RU: dict[str, str] = {
    "initiated": "запустил",
    "spawned": "породил",
    "runs": "выполняет",
    "network": "обратился к",
    # Учётная запись на узле. Без этого вида связи событие промышленного источника —
    # узел и учётная запись без процесса — не давало ни одной связи, и узел оставался
    # на графе висячей вершиной. То же название использует граф цепочки на «Симуляции».
    "acts_on": "действует на",
}
"""Вид связи между сущностями кейса (`graph.edges[].type`)."""

TYPICALITY_RU: dict[str, str] = {
    "first_seen": "первое появление",
    "rare": "редко: менее 3 событий",
    "burst": "вспышка: всё в пределах одного часа",
    "typical": "часто: 3 и более событий в разные часы",
}
"""Частота сущности в накопленной истории. Это счётчик событий, а не модель поведения:
порог назван прямо в самом названии, чтобы «обычная активность» не читалась как вывод
о нормальности.

«Вспышка» отделена от «часто» по той же причине: 51 событие за 50 секунд и 51 событие за
неделю — разные наблюдения, а счётчик у них одинаковый. Порог периода, достаточного для
суждения о типичности, согласуется с заказчиком; до тех пор продукт называет наблюдаемое,
а вывода о норме не делает."""

ROLE_RU: dict[str, str] = {
    "analyst_l1": "аналитик первой линии",
    "analyst_l2": "аналитик второй линии",
    "manager": "руководитель",
    "admin": "администратор",
    "operator": "оператор",
    "auditor": "аудитор",
}
"""Роль ключа доступа (`role` в ответе `GET /session`).

Роль видна аналитику в шапке рабочего места: она объясняет, почему часть действий недоступна.
Названия живут здесь, а не в АРМ, по общему правилу словаря — иначе при добавлении роли
интерфейс молча показал бы код."""

DQ_REASON_RU: dict[str, str] = {
    "telemetry_gap": "разрыв в телеметрии",
    "stale_data": "устаревшие данные",
    "source_reputation_drift": "просадка доверия к источнику",
}
"""Причины неполной наблюдаемости (`dq_reasons`)."""

LEDGER_ISSUE_RU: dict[str, str] = {
    "line_sha_mismatch": "контрольная сумма записи не сходится",
    "payload_sha_mismatch": "контрольная сумма содержимого не сходится",
    "prev_chain_mismatch": "разрыв цепочки: ссылка на предыдущую запись не сходится",
    "chain_mismatch": "контрольная сумма цепочки не сходится",
}
"""Нарушения целостности append-only журнала (`issue` в ответе проверки).

Это сообщение аналитик читает в тот момент, когда доказательный контур под вопросом:
код вроде `prev_chain_mismatch` здесь хуже всего, потому что требует перевода на ходу."""


def risk_class_ru(value: str) -> str:
    """Название класса риска. Неизвестный код возвращается как есть, а не подменяется догадкой."""
    return RISK_CLASS_RU.get((value or "").strip().upper(), value)


def case_status_ru(value: str) -> str:
    """Название статуса дела. Неизвестный код возвращается как есть."""
    return CASE_STATUS_RU.get((value or "").strip(), value)


def plural_ru(count: int, one: str, few: str, many: str) -> str:
    """Согласование существительного с числительным: 1 событие, 2 события, 5 событий.

    Нужно там, где текст собирается продуктом и уходит пользователю: «Собрано 41 событий»
    в сводке кейса читается как небрежность ровно в том месте, где продукт объясняет
    основание вывода.
    """
    tail_two = abs(count) % 100
    tail_one = abs(count) % 10
    if 11 <= tail_two <= 14:
        return many
    if tail_one == 1:
        return one
    if 2 <= tail_one <= 4:
        return few
    return many


def events_ru(count: int) -> str:
    """«1 событие» / «2 события» / «5 событий» вместе с числом."""
    return f"{count} {plural_ru(count, 'событие', 'события', 'событий')}"


def vocabulary() -> dict[str, dict[str, str]]:
    """Весь словарь одним объектом — то, что отдаётся интерфейсу."""
    return {
        "risk_class": dict(RISK_CLASS_RU),
        "case_status": dict(CASE_STATUS_RU),
        "verdict": dict(VERDICT_RU),
        "event_source": dict(EVENT_SOURCE_RU),
        "entity_type": dict(ENTITY_TYPE_RU),
        "artifact_type": dict(ARTIFACT_TYPE_RU),
        "correlation_rule": dict(CORRELATION_RULE_RU),
        "chain_step_kind": dict(CHAIN_STEP_KIND_RU),
        "graph_edge_kind": dict(GRAPH_EDGE_KIND_RU),
        "typicality": dict(TYPICALITY_RU),
        "dq_reason": dict(DQ_REASON_RU),
        "ledger_issue": dict(LEDGER_ISSUE_RU),
        "role": dict(ROLE_RU),
        "permit_verdict": dict(PERMIT_VERDICT_RU),
        "case_coverage": dict(CASE_COVERAGE_RU),
        "process_identity": dict(PROCESS_IDENTITY_RU),
        "analytic_confidence": dict(ANALYTIC_CONFIDENCE_RU),
    }
