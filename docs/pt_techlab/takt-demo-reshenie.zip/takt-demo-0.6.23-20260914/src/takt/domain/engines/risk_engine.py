from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RiskBreakdown:
    rhythm: float
    graph: float
    context: float
    user: float
    data_quality: float


@dataclass(frozen=True, slots=True)
class RiskAssessment:
    score: float
    risk_class: str
    breakdown: RiskBreakdown


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def asymptotic_normalize(raw: float, cap: float) -> float:
    """Плато при экстремальной нагрузке (мягкая отсечка)."""
    if cap <= 0:
        return 0.0
    return _clamp(raw / (raw + cap))


def mandelbrot_entropy_proxy(values: list[float], entropy_cap: float) -> float:
    """
    Упрощённый «порог устойчивости»: дисперсия нормированных вкладов не выше cap.
    Возвращает множитель доверия 0..1.
    """
    if not values:
        return 1.0
    m = sum(values) / len(values)
    var = sum((v - m) ** 2 for v in values) / len(values)
    if var <= entropy_cap:
        return 1.0
    return _clamp(entropy_cap / var if var else 1.0)


def combine_risk(
    vectors: RiskBreakdown,
    weights: Mapping[str, float],
    *,
    dq_score: float,
    eps_estimate: float,
    mandel_cap: float,
    eps_soft_cap: float,
    risk_class_thresholds: Mapping[str, float] | None = None,
) -> RiskAssessment:
    """
    Risk = F(R, G, C, U, DQ) с учётом асимптотики EPS.
    Пороги классов риска задаются через risk_class_thresholds (из YAML).

    Качество данных входит в оценку ровно одним каналом — взвешенным вектором
    `vectors.data_quality`, наравне с остальными четырьмя измерениями. Параметр
    `dq_score` на итоговый балл больше не влияет и сохранён в сигнатуре как часть
    контракта вызова: вызывающие передают его вместе с векторами и используют для
    собственных решений о частичности данных.
    """
    wsum = (
        weights["rhythm"] * vectors.rhythm
        + weights["graph"] * vectors.graph
        + weights["context"] * vectors.context
        + weights["user"] * vectors.user
        + weights["data_quality"] * vectors.data_quality
    )
    burst = asymptotic_normalize(eps_estimate, eps_soft_cap)
    # Интенсивность потока только усиливает оценку и никогда её не ослабляет.
    #
    # Прежняя запись `(0.5 + 0.5 * burst)` делила балл пополам при штатной работе: при
    # `eps_soft_cap = 100000` значение `burst` не отрывается от нуля на достижимых частотах
    # (10 000 соб/с — 0.09). Потолок оценки был 0.5, поэтому пороги HIGH (0.65) и
    # CRITICAL (0.85) из `config/risk_weights.yaml` не достигались ни при каких
    # срабатываниях инвариантов; лестница классов сходилась только в тесте, где поток
    # задан как 50 млн событий в секунду.
    #
    # Теперь при обычном потоке множитель равен 1.0 и балл читается как уровень признаков:
    # равномерные векторы 0.95 дают CRITICAL, 0.7 — HIGH, 0.45 — MEDIUM. Рост с EPS
    # сохранён (`tests/test_risk_engine_100k_eps.py::test_risk_monotonic_with_eps`), но
    # при экстремальном потоке балл упирается в 1.0 — верх шкалы там не различает случаи.
    # Решение и разбор — `docs/risk_scale_calibration.md`.
    #
    # Множителя качества данных здесь больше нет. Прежняя запись `wsum * dq_factor * (...)`
    # использовала одно измерение дважды и в противоположных направлениях: испорченные данные
    # поднимали вектор `data_quality` (вектор считается вызывающими как `1 - dq_score`) и тем
    # же движением занижали множитель, который умножал весь балл целиком — включая вклад
    # четырёх остальных векторов. При `dq_score = 0` балл обнулялся независимо от признаков
    # атаки, а вес качества (0.20) нельзя было «получить»: максимум достигался при идеальных
    # данных, где вектор равен нулю. Достижимый потолок шкалы был из-за этого 0.800, и пороги
    # классов приходилось назначать долями от него.
    #
    # Теперь качество влияет ровно одним каналом — своим взвешенным вектором, как остальные
    # четыре измерения; потолок вернулся к 1.000, пороги в `config/risk_weights.yaml`
    # откачены к 0.85 / 0.65 / 0.40. Знак влияния при этом сменился намеренно (решение
    # владельца 2026-08-24): ухудшение данных теперь балл повышает, а не понижает — потеря
    # видимости считается признаком риска, а не поводом смягчить разбор.
    adj = wsum * (1.0 + burst)
    trust = mandelbrot_entropy_proxy(
        [vectors.rhythm, vectors.graph, vectors.context, vectors.user, vectors.data_quality],
        mandel_cap,
    )
    score = _clamp(adj * trust)
    thresholds = risk_class_thresholds or {}
    critical = float(thresholds.get("critical", 0.85))
    high = float(thresholds.get("high", 0.65))
    medium = float(thresholds.get("medium", 0.4))
    if score >= critical:
        rclass = "CRITICAL"
    elif score >= high:
        rclass = "HIGH"
    elif score >= medium:
        rclass = "MEDIUM"
    else:
        rclass = "LOW"
    return RiskAssessment(score=score, risk_class=rclass, breakdown=vectors)


_RISK_CLASS_RANK: dict[str, int] = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}


def worst_risk_class(a: str, b: str) -> str:
    """Более «тяжёлый» из двух классов (для тот же score или агрегации при merge)."""
    ra = _RISK_CLASS_RANK.get(a.upper(), 0)
    rb = _RISK_CLASS_RANK.get(b.upper(), 0)
    return a if ra >= rb else b
