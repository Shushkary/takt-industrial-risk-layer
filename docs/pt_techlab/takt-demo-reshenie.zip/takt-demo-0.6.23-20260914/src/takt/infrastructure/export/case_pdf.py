"""Генерация PDF «паспорт инцидента» (спринт 11 ТЗ). Требует extra: pip install '.[export]'

Здесь же — одностраничная сводка для лица, принимающего решение (разрыв G-5,
``docs/customer_value_map.md``). Паспорт и сводка различаются не оформлением, а адресатом:
паспорт даёт аналитику весь состав дела, сводка даёт руководителю ровно то, по чему он решает.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from takt.domain.entities.case import Case, CaseArtifact
from takt.domain.services.decision_brief import decision_brief
from takt.domain.services.verdict_confidence import MissingContextItem

_PROJECT_ROOT = Path(__file__).resolve().parents[4]


def _latin1_safe(text: str) -> str:
    """Fallback для Helvetica — только latin-1."""
    return text.encode("latin-1", errors="replace").decode("latin-1")


def _break_long_tokens(text: str, *, max_token_len: int = 16) -> str:
    parts: list[str] = []
    for token in text.split(" "):
        if len(token) <= max_token_len:
            parts.append(token)
            continue
        chunks = [token[i : i + max_token_len] for i in range(0, len(token), max_token_len)]
        parts.append(" ".join(chunks))
    return " ".join(parts)


def _pdf_visible_audit_log(case: Case) -> list[str]:
    return [entry for entry in case.audit_log if "pdf exported sha256=" not in entry]


# Пределы разделов паспорта. Усечение допустимо — молчаливое усечение нет: обрезанный итог
# выглядит полным, и получатель не знает, что смотрит на часть.
_MAX_FINDINGS = 50
_MAX_ARTIFACTS = 100
_MAX_DECISIONS = 50
_MAX_AUDIT = 50


def _truncation_note(total: int, limit: int) -> str:
    return f" (truncated: {limit} of {total})" if total > limit else ""


def _artifact_line(artifact: CaseArtifact) -> str:
    """Артефакт вместе с узлом и статусом проверки.

    Без узла объект остаётся без привязки, и получателю нечего с ним делать; без статуса
    проверки непроверенное значение читается как установленный факт.
    """
    host = artifact.host_id or "host unknown"
    status = artifact.verification_status or "unverified"
    source = artifact.source or "-"
    return f"- [{artifact.type}] {artifact.value} | {host} | {status} | source={source}"


def _finding_lines(case: Case) -> list[str]:
    """Содержание находок, а не факт их добавления.

    Журнал показывал `case.finding.add appended` — то есть что находка была, — но не то, что
    в ней написано. Связный итог приходилось собирать заново из отдельных выгрузок.
    """
    total = len(case.findings)
    lines = [f"Findings: {total}{_truncation_note(total, _MAX_FINDINGS)}"]
    if not total:
        lines.append("-")
        return lines
    for finding in case.findings[:_MAX_FINDINGS]:
        created = finding.created_at.isoformat(timespec="seconds") if finding.created_at else "-"
        mark = " [historical]" if getattr(finding, "historical", False) else ""
        origin = getattr(finding, "origin_case_id", "")
        origin_mark = f" [from case {origin}]" if origin and origin != case.case_id else ""
        lines.append(f"- {finding.text}{mark}{origin_mark}")
        lines.append(f"  {finding.author or '-'} | {created} | events: {', '.join(finding.event_ids) or '-'}")
        for artifact in finding.artifacts:
            lines.append(f"  {_artifact_line(artifact)}")
    return lines


def _artifact_section(case: Case) -> list[str]:
    total = len(case.artifacts)
    lines = [f"Artifacts: {total}{_truncation_note(total, _MAX_ARTIFACTS)}"]
    if not total:
        lines.append("-")
        return lines
    lines.extend(_artifact_line(artifact) for artifact in case.artifacts[:_MAX_ARTIFACTS])
    return lines


def _decision_section(case: Case) -> list[str]:
    """Основания решений: паспорт обязан отвечать, почему дело закрыли именно так."""
    total = len(case.decision_records)
    lines = [f"Decisions: {total}{_truncation_note(total, _MAX_DECISIONS)}"]
    if not total:
        lines.append("-")
        return lines
    for record in case.decision_records[:_MAX_DECISIONS]:
        ts = record.ts.isoformat(timespec="seconds") if hasattr(record.ts, "isoformat") else str(record.ts)
        lines.append(f"- {ts} | {record.actor or '-'} | {record.prev_status} -> {record.next_status}")
        lines.append(f"  reason: {record.reason or '-'}")
    return lines


def _summary_section(case: Case) -> list[str]:
    """Итоговое описание расследования — то, ради чего паспорт берут в руки.

    В документ идёт утверждённая редакция; неутверждённая печатается с пометкой «черновик».
    Разница существенна: черновик — рабочая запись аналитика, утверждённая редакция — итог,
    который он предъявляет.
    """
    from takt.application.use_cases.investigation_summary import SECTIONS

    versions = case.investigation_summaries
    if not versions:
        return ["Investigation summary: -"]
    approved = [item for item in versions if item.approved]
    record = approved[-1] if approved else versions[-1]
    state = "approved" if record.approved else "DRAFT (not approved)"
    lines = [
        f"Investigation summary (version {record.version}, {state})",
        f"Author: {record.author or '-'} | {record.created_at.isoformat(timespec='seconds')}"
        f" | confidence: {record.confidence or '-'} | sha256: {record.checksum[:16]}",
    ]
    if record.approved:
        approved_at = record.approved_at.isoformat(timespec="seconds") if record.approved_at else "-"
        lines.append(f"Approved by: {record.approved_by or '-'} | {approved_at}")
    for section in SECTIONS:
        text = (record.sections.get(section.key) or "").strip()
        lines.append(f"{section.title}:")
        lines.append(text or "-")
    return lines


def _open_questions(case: Case) -> list[str]:
    """Нерешённые вопросы: чего в деле не хватает на момент выгрузки.

    Список строится из уже посчитанного продуктом, а не выводится заново: неполнота качества
    данных, отсутствие решения аналитика и незакрытая сверка организационного контекста.
    """
    questions: list[str] = []
    if case.dq_partial or case.dq_reasons:
        reasons = ", ".join(case.dq_reasons) or "partial observability"
        questions.append(f"- data quality is incomplete: {reasons}")
    if not case.decision_records:
        questions.append("- analyst decision is not recorded")
    if not case.manual_permits:
        questions.append("- organizational context document is not attached")
    if not case.findings:
        questions.append("- no findings recorded by the analyst")
    return ["Open questions:", *(questions or ["-"])]


def _open_document(ts: datetime, unicode_font_path: str | None) -> tuple[Any, str | None, str]:
    """Пустой документ с подключённым шрифтом. Общая часть паспорта и сводки."""
    try:
        from fpdf import FPDF
    except ImportError as e:
        raise RuntimeError(
            "Для PDF установите зависимость: pip install 'takt-industrial-risk-layer[export]'"
        ) from e

    pdf = FPDF()
    if hasattr(pdf, "set_creation_date"):
        pdf.set_creation_date(ts)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    font_file: str | None = None
    if unicode_font_path:
        candidate = Path(unicode_font_path).expanduser()
        if not candidate.is_absolute():
            candidate = _PROJECT_ROOT / candidate
        p = candidate.resolve()
        try:
            p.relative_to(_PROJECT_ROOT.resolve())
        except ValueError:
            p = _PROJECT_ROOT / "__outside_project_font_is_not_allowed__"
        if p.is_file():
            font_file = str(p)
            pdf.add_font("TaktUni", "", font_file)

    return pdf, font_file, ("TaktUni" if font_file else "Helvetica")


def _document_bytes(pdf: Any) -> bytes:
    out = pdf.output()
    if isinstance(out, str):
        return out.encode("latin-1")
    return bytes(out)


def render_case_pdf(
    case: Case,
    *,
    generated_at: datetime | None = None,
    unicode_font_path: str | None = None,
) -> bytes:
    ts = generated_at or datetime.now()
    pdf, font_file, body_font = _open_document(ts, unicode_font_path)

    pdf.set_font(body_font, "", 16)
    pdf.cell(0, 10, "TAKT Industrial Risk Layer", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(body_font, "", 11)
    pdf.cell(0, 8, f"Incident passport / Case {case.case_id}", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    def T(s: str) -> str:
        return s if font_file else _latin1_safe(s)

    lines = [
        f"Generated (UTC): {ts.isoformat(timespec='seconds')}",
        f"Status: {case.status.value}",
        f"Risk class: {case.risk_class}",
        f"Risk score: {case.risk_score:.4f}",
        f"Data quality: {case.dq_score:.4f} (partial={case.dq_partial})",
        f"DQ reasons: {', '.join(case.dq_reasons) if case.dq_reasons else '-'}",
        f"Title: {T(case.title)}",
        f"Primary asset: {case.primary_asset_id or '-'}",
        f"Last event source: {case.last_event_source or '-'}",
        f"Trigger operation: {case.trigger_operation or '-'}",
        f"Fingerprint: {case.burst_fingerprint or '-'}",
        "",
        "Invariant hits:",
        ", ".join(case.invariant_hits) if case.invariant_hits else "-",
        "",
        "XAI summary:",
        T(case.xai_summary[:4000]),
        "",
        "Normalized event IDs:",
        ", ".join(case.normalized_event_ids) or "-",
        "",
        # Итог расследования идёт первым разделом после карточки: получатель читает ответ,
        # а не собирает его из состава событий и журнала.
        T("\n".join(_summary_section(case))),
        "",
        # Содержание находок, артефакты с узлами и основания решений: до этой правки паспорт
        # нёс только строку журнала о том, что находка была добавлена.
        T("\n".join(_finding_lines(case))),
        "",
        T("\n".join(_artifact_section(case))),
        "",
        T("\n".join(_decision_section(case))),
        "",
        T("\n".join(_open_questions(case))),
        "",
        f"Audit trail{_truncation_note(len(_pdf_visible_audit_log(case)), _MAX_AUDIT)}:",
        "\n".join(T(x) for x in _pdf_visible_audit_log(case)[-_MAX_AUDIT:]) if _pdf_visible_audit_log(case) else "-",
    ]

    pdf.set_font(body_font, "", 10)

    def write_paragraph(paragraph: str) -> None:
        if hasattr(pdf, "set_x") and hasattr(pdf, "l_margin"):
            pdf.set_x(pdf.l_margin)
        pdf.multi_cell(0, 5, _break_long_tokens(paragraph))

    for block in lines:
        for paragraph in block.split("\n"):
            write_paragraph(T(paragraph))
        pdf.ln(1)

    return _document_bytes(pdf)


def render_decision_brief_pdf(
    case: Case,
    *,
    generated_at: datetime | None = None,
    unicode_font_path: str | None = None,
) -> bytes:
    """Один лист для того, кто принимает решение.

    Порядок блоков — порядок вопросов руководителя: вывод и обоснованность, потом чего не
    хватает, потом чем подтверждено, и только затем подробности. Маршрут добора идёт выше
    доказательств намеренно: если вердикт неопределённый, читать остальное незачем, пока
    документ не добран.
    """
    ts = generated_at or datetime.now()
    brief = decision_brief(case)
    pdf, font_file, body_font = _open_document(ts, unicode_font_path)

    def T(s: str) -> str:
        return s if font_file else _latin1_safe(s)

    pdf.set_font(body_font, "", 16)
    pdf.cell(0, 10, T("ТАКТ — сводка для принятия решения"), new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(body_font, "", 11)
    pdf.cell(0, 8, T(f"Дело {brief.case_id} · {brief.status}"), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    missing_block = (
        "\n".join(f"- {_missing_line(item)}" for item in brief.missing)
        if brief.missing
        else "- контекста достаточно, вердикт определён"
    )
    measures_block = (
        "\n".join(f"- {m.kind} [{m.status}] {m.action}".rstrip() for m in brief.measures)
        if brief.measures
        else "- меры в деле не зафиксированы"
    )
    decision = brief.last_decision
    decision_line = (
        f"{decision.ts.isoformat(timespec='seconds')} · {decision.actor} · "
        f"{decision.prev_status} -> {decision.next_status} · {decision.reason or '-'}"
        if decision is not None
        else "решение по делу не зафиксировано"
    )

    blocks = [
        f"Сформировано (UTC): {ts.isoformat(timespec='seconds')}",
        f"Заведено: {brief.created_at.isoformat(timespec='seconds')}",
        f"Инцидент: {brief.title}",
        "",
        "ВЫВОД",
        f"Вердикт: {brief.verdict_value} ({brief.verdict})",
        f"Обоснованность: {brief.confidence_grade} ({brief.confidence_score:.2f} из 1.00)",
        f"Риск: {brief.risk_class} ({brief.risk_score:.2f})",
        "",
        "ЧЕГО НЕ ХВАТАЕТ",
        missing_block,
        "",
        "ЧЕМ ПОДТВЕРЖДЕНО",
        f"- сырых доказательств: {brief.evidence.raw_evidence_count}",
        f"- организационных документов с контрольной суммой: {brief.evidence.organizational_documents}",
        f"- записей аудиторского следа: {brief.evidence.audit_entries}",
        f"- доказательный пакет собран: {'да' if brief.evidence.forensic_bundle_exported else 'нет'}",
        "",
        "ЧТО ПРОИЗОШЛО",
        brief.explanation or "-",
        "Сработавшие инварианты:",
        "\n".join(f"- {title}" for title in brief.invariants) if brief.invariants else "- нет",
        "",
        "МЕРЫ",
        measures_block,
        "",
        "ПОСЛЕДНЕЕ РЕШЕНИЕ",
        decision_line,
        "",
        brief.boundary_note,
    ]

    pdf.set_font(body_font, "", 10)
    for block in blocks:
        for paragraph in block.split("\n"):
            if hasattr(pdf, "set_x") and hasattr(pdf, "l_margin"):
                pdf.set_x(pdf.l_margin)
            pdf.multi_cell(0, 5, _break_long_tokens(T(paragraph)))
        pdf.ln(1)

    return _document_bytes(pdf)


def _missing_line(item: MissingContextItem) -> str:
    """Пункт маршрута добора с адресом: какой документ, у кого, за какое окно."""
    parts = [item.text]
    if item.required_document:
        parts.append(f"документ: {item.required_document}")
    if item.sanctioning_party:
        parts.append(f"утверждающий: {item.sanctioning_party}")
    if item.admissible_window:
        parts.append(f"окно: {item.admissible_window}")
    return " · ".join(parts)
